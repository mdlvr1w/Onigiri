This is Onigiri, a Desktop Rice helper for KDE Plasma.
Onigiri uses KWin rules to create a custom dashboard via a lightweight PyQt6 GUI.

This is still work in progress - while the core features are working, i cannot guarantee the experience will be without errors.
